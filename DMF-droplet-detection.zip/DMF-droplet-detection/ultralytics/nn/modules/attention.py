import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn as nn
import math

class ECA(nn.Module):
    """ECA注意力机制 - 高效的通道注意力模块"""
    def __init__(self, channel, gamma=2, b=1):
        super(ECA, self).__init__()
        # 自适应计算卷积核大小
        t = int(abs((math.log(channel, 2) + b) / gamma))
        k_size = t if t % 2 else t + 1
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, 
                             padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 全局平均池化获取通道描述符
        y = self.avg_pool(x)  # [B, C, 1, 1]
        # 调整维度以适应1D卷积 [B, C, 1, 1] -> [B, 1, C]
        y = y.squeeze(-1).transpose(-1, -2)
        # 1D卷积计算通道权重
        y = self.conv(y)  # [B, 1, C]
        # 调整维度并应用Sigmoid [B, 1, C] -> [B, C, 1, 1]
        y = self.sigmoid(y).transpose(-1, -2).unsqueeze(-1)

        # 特征重标定
        return x * y.expand_as(x)
        
class SpatialAttention(nn.Module):
    """CBAM的空间注意力模块"""
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)
        
import torch
import torch.nn as nn

class ChannelAttention(nn.Module):
    """动态通道注意力，自动适应输入通道"""
    def __init__(self, in_planes, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        # 动态计算中间层
        self.fc = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // reduction, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_planes // reduction, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 自动获取输入通道数
        in_planes = x.size(1)
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)

class CBAM(nn.Module):
    """CBAM模块，完全动态适应输入"""
    def __init__(self, c1, reduction=16, kernel_size=7):
        super().__init__()
        # 这里的c1参数仅用于初始化，实际会动态适应
        self.channel_attention = ChannelAttention(c1, reduction)
        self.spatial_attention = SpatialAttention(kernel_size)
        
    def forward(self, x):
        # 动态创建适应输入通道的模块
        if not hasattr(self, '_initialized') or self._initialized != x.size(1):
            self._initialized = x.size(1)
            # 重新初始化通道注意力以适应实际输入通道
            self.channel_attention = ChannelAttention(x.size(1)).to(x.device)
        
        x = self.channel_attention(x) * x
        x = self.spatial_attention(x) * x
        return x
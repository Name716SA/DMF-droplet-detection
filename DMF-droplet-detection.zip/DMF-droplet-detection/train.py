import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

model = YOLO('./ultralytics/cfg/models/v12/my yolov12.yaml')
model.load('yolov12n.pt')
results = model.train(
    data='data.yaml',  #数据集配置文件的路径
    epochs=50,  #训练轮次总数
    batch=16,  #批量大小，即单次输入多少图片训练
    imgsz=640,  #训练图像尺寸
    scale=0.5,  # S:0.9; M:0.9; L:0.9; X:0.9 #增益因子缩放图像，模拟物体与摄像机的不同距离。
    mosaic=1.0,  #默认值
    mixup=0.0,  # S:0.05; M:0.15; L:0.15; X:0.2  #默认值
    copy_paste=0.1,  # S:0.15; M:0.4; L:0.5; X:0.6  #分割标签 进行复制和粘贴
    device= 'cpu',  #指定训练的计算设备，无nvidia显卡则改为 'cpu'
    #以下为我添加的一些参数
    optimizer='SGD',  #训练使用优化器，可选 auto,SGD,Adam,AdamW 等
    workers=8,  #加载数据的工作线程数
    amp= True,  #True 或者 False, 解释为：自动混合精度(AMP) 训练
    cache=False  # True 在内存中缓存数据集图像，服务器推荐开启
)
# config.py - 项目路径与参数配置
# 说明：所有路径、模型文件、输出目录等均集中在此文件，用户只需修改此处即可适配自己的环境。

# ---------- YOLOv12 项目根目录 ----------
# 用于添加系统路径（导入 ultralytics 等）以及作为其他相对路径的基准
YOLO_ROOT = r"I:/PythonProjectYolo/yolov12-main"

# ---------- YOLO 模型文件路径 ----------
# 芯片定位模型
CHIP_MODEL_PATH = r"I:/PythonProjectYolo/yolov12-main/elec_train8_best.pt"
# 液滴检测模型
DROPLET_MODEL_PATH = r"I:/PythonProjectYolo/yolov12-main/my_model_best.pt"

# ---------- 通用输出目录 ----------
# 电极分割图像、临时文件、视频录像等均存放在此目录下
OUTPUT_DIR = r"I:/PythonProjectYolo/yolov12-main/CLC2"

# ---------- 命令发送基础目录 ----------
# send_commands 功能所依赖的命令文件存放目录（通常是 DropletCheck 文件夹）
# 与硬件数据交互文件夹（通常是 DropletCheck 文件夹）
COMMAND_BASE_DIR = r"F:/digital microfluidics/Virus/DropletCheck"

# ---------- 视频保存目录 ----------
VIDEO_DIR = r"I:/PythonProjectYolo/yolov12-main/CLC"

# ---------- 摄像头 ID ----------
# CAMERA_ID = 1 表示外接摄像头
CAMERA_ID = 1
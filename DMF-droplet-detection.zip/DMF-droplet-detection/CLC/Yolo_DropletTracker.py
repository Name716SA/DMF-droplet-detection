import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

import sys
import numpy as np
import cv2
import torch
import math
import time
from typing import List, Tuple, Dict, Any

import config
sys.path.append(config.YOLO_ROOT)
from ultralytics import YOLO

# Class names
chip_class_names = ['chip1', 'chip2']
droplet_class_names = ['static', 'merging', 'splitting', 'stretching']

# Big electrode array (6 rows x 8 columns)
big_grid = [
    [46, 47, 48, 49, 50, 13, 24, 30],
    [38, 39, 40, 41, 42, 43, 44, 45],
    [30, 31, 32, 33, 34, 35, 36, 37],
    [22, 23, 24, 25, 26, 27, 28, 29],
    [14, 15, 16, 17, 18, 19, 20, 21],
    [6, 7, 8, 9, 10, 11, 12, 13]
]

# Small electrode array (9 rows x 6 columns)
small_grid = [
    [36, 37, 30, 25, 24, 18],
    [13, 12, 6, 50, 49, 48],
    [47, 46, 45, 44, 43, 42],
    [41, 40, 39, 38, 37, 36],
    [35, 34, 33, 32, 31, 30],
    [28, 27, 29, 26, 25, 24],
    [22, 23, 21, 20, 19, 18],
    [17, 16, 15, 14, 13, 12],
    [11, 10, 9, 8, 7, 6]
]

class DropletTracker:
    """Droplet tracker based on Euclidean distance."""
    def __init__(self, detector=None):
        self.next_id = 0
        self.tracked_droplets = {}  # {id: {'coords': coords, 'center': center, 'electrode_id': id, 'age': 0}}
        self.max_age = 10  # Maximum number of missing frames
        self.detector = detector  # Reference to detector for electrode info

        # Dynamically computed thresholds
        self.big_threshold = None
        self.small_threshold = None

    def calculate_distance_thresholds(self):
        """Dynamically compute distance thresholds based on electrode layout."""
        if not self.detector or not self.detector.electrodes_initialized:
            # Fallback to default values if detector unavailable or electrodes not initialized
            self.big_threshold = 150
            self.small_threshold = 100
            return

        # Compute typical distances for big electrodes
        big_distances = []
        for row in range(len(big_grid)):
            for col in range(len(big_grid[0]) - 1):
                # Distance between adjacent electrodes in the same row
                electrode1 = self.detector.get_electrode_by_coords((0, row, col))
                electrode2 = self.detector.get_electrode_by_coords((0, row, col + 1))
                if electrode1 and electrode2:
                    dist = self._euclidean_distance(electrode1['center'], electrode2['center'])
                    big_distances.append(dist)

        # Compute typical distances for small electrodes
        small_distances = []
        for row in range(len(small_grid)):
            for col in range(len(small_grid[0]) - 1):
                # Distance between adjacent electrodes in the same row
                electrode1 = self.detector.get_electrode_by_coords((1, row, col))
                electrode2 = self.detector.get_electrode_by_coords((1, row, col + 1))
                if electrode1 and electrode2:
                    dist = self._euclidean_distance(electrode1['center'], electrode2['center'])
                    small_distances.append(dist)

        # Set threshold to twice the median distance (conservative estimate)
        if big_distances:
            self.big_threshold = np.median(big_distances) * 2
            print(f"BT:{self.big_threshold}")
        else:
            self.big_threshold = 150

        if small_distances:
            self.small_threshold = np.median(small_distances) * 2
            print(f"ST:{self.small_threshold}")
        else:
            self.small_threshold = 100

        print(f"Computed distance thresholds - big: {self.big_threshold:.2f}px, small: {self.small_threshold:.2f}px")

    def update(self, current_droplets):
        """Update tracked droplets with new detections."""
        # Compute thresholds on first update
        if self.big_threshold is None or self.small_threshold is None:
            self.calculate_distance_thresholds()

        # Initialize if no droplets are being tracked
        if not self.tracked_droplets:
            for droplet in current_droplets:
                self.tracked_droplets[self.next_id] = {
                    'coords': droplet['coords'],
                    'center': droplet['center'],
                    'electrode_id': droplet['electrode_id'],
                    'type': droplet.get('type', 'unknown'),
                    'age': 0
                }
                self.next_id += 1
            return

        # Compute distance matrix
        distance_matrix = self._compute_distance_matrix(current_droplets)

        # Match existing tracks
        matched_pairs = self._match_droplets(distance_matrix)

        # Update matched droplets
        for track_id, droplet_idx in matched_pairs:
            droplet = current_droplets[droplet_idx]
            self.tracked_droplets[track_id] = {
                'coords': droplet['coords'],
                'center': droplet['center'],
                'electrode_id': droplet['electrode_id'],
                'type': droplet.get('type', 'unknown'),
                'age': 0
            }

        # Handle unmatched detections (new droplets)
        matched_droplet_indices = set(idx for _, idx in matched_pairs)
        for i, droplet in enumerate(current_droplets):
            if i not in matched_droplet_indices:
                self.tracked_droplets[self.next_id] = {
                    'coords': droplet['coords'],
                    'center': droplet['center'],
                    'electrode_id': droplet['electrode_id'],
                    'age': 0
                }
                self.next_id += 1

        # Handle lost tracks
        lost_tracks = []
        for track_id in list(self.tracked_droplets.keys()):
            if track_id not in [tid for tid, _ in matched_pairs]:
                self.tracked_droplets[track_id]['age'] += 1
                if self.tracked_droplets[track_id]['age'] > self.max_age:
                    lost_tracks.append(track_id)

        for track_id in lost_tracks:
            del self.tracked_droplets[track_id]

    def _compute_distance_matrix(self, current_droplets):
        """Compute distance matrix between tracked droplets and current detections."""
        distance_matrix = []

        for track_id, tracked_droplet in self.tracked_droplets.items():
            distances = []
            for droplet in current_droplets:
                # Only compute distances within the same array type
                if tracked_droplet['coords'][0] == droplet['coords'][0]:
                    dist = self._euclidean_distance(tracked_droplet['center'], droplet['center'])
                    distances.append(dist)
                else:
                    distances.append(float('inf'))
            distance_matrix.append(distances)

        return distance_matrix

    def _euclidean_distance(self, point1, point2):
        """Compute Euclidean distance between two points."""
        return np.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

    def _match_droplets(self, distance_matrix):
        """Match tracked droplets to current detections using greedy assignment."""
        matched_pairs = []
        used_tracks = set()
        used_droplets = set()

        # Simple greedy matching
        for track_idx, distances in enumerate(distance_matrix):
            track_id = list(self.tracked_droplets.keys())[track_idx]

            if track_id in used_tracks:
                continue

            # Find minimum distance
            min_dist = float('inf')
            min_idx = -1

            for droplet_idx, dist in enumerate(distances):
                if droplet_idx in used_droplets:
                    continue

                if dist < min_dist:
                    min_dist = dist
                    min_idx = droplet_idx

            # Use dynamically computed threshold
            threshold = self._get_distance_threshold(track_idx)

            if min_idx != -1 and min_dist < threshold:
                matched_pairs.append((track_id, min_idx))
                used_tracks.add(track_id)
                used_droplets.add(min_idx)

        return matched_pairs

    def _get_distance_threshold(self, track_idx):
        """Retrieve appropriate distance threshold based on electrode type."""
        track_id = list(self.tracked_droplets.keys())[track_idx]
        droplet_type = self.tracked_droplets[track_id]['coords'][0]

        if droplet_type == 0:  # Big electrode
            return self.big_threshold
        else:  # Small electrode
            return self.small_threshold

    def get_tracked_droplets(self):
        """Return a copy of currently tracked droplets."""
        return self.tracked_droplets.copy()

class VideoElectrodeDetector:
    def __init__(self):
        # Load two independent YOLO models
        self.chip_model = YOLO(config.CHIP_MODEL_PATH)
        self.chip_model.to('cpu')
        self.droplet_model = YOLO(config.DROPLET_MODEL_PATH)
        self.droplet_model.to('cpu')
        # Custom Euclidean distance-based tracker
        self.tracker = DropletTracker(detector=self)  # Pass self reference to tracker

        self.big_electrodes = []   # Big electrode segmentation results
        self.small_electrodes = [] # Small electrode segmentation results
        self.chip1_coords = None
        self.chip2_coords = None
        self.electrodes_initialized = False

        # Electrode status management
        self.electrode_status = {}  # 'normal', 'obstacle', 'damaged'
        self.obstacle_electrodes = set()  # Set of obstacle electrode IDs

    def initialize_electrodes_from_frame(self, frame: np.ndarray) -> bool:
        """Initialize electrode positions from the first frame and save segmentation image."""
        try:
            # Ensure output directory exists
            output_dir = config.OUTPUT_DIR
            os.makedirs(output_dir, exist_ok=True)

            # Save first frame for electrode initialization
            temp_image_path = os.path.join(output_dir, "temp_first_frame.jpg")
            cv2.imwrite(temp_image_path, frame)

            # Detect chip1 and chip2
            chips = self.detect_chips(temp_image_path)

            if 'chip1' not in chips or 'chip2' not in chips:
                print("Failed to detect alignment chips in the first frame")
                return False

            # Segment electrodes
            self.segment_electrodes(chips, frame.shape[:2])
            self.electrodes_initialized = True
            print("Electrode initialization completed successfully")

            # Initialize electrode status
            self.initialize_electrode_status()

            # Save electrode segmentation image
            self.save_electrode_segmentation_image(frame, output_dir)

            return True

        except Exception as e:
            print(f"Electrode initialization failed: {e}")
            return False

    def initialize_electrode_status(self):
        """Initialize all electrodes to normal status."""
        for electrode in self.big_electrodes + self.small_electrodes:
            self.electrode_status[electrode['electrode_id']] = 'normal'

    def get_electrode_by_id(self, electrode_id: int) -> Dict:
        """Retrieve electrode information by its ID."""
        for electrode in self.big_electrodes + self.small_electrodes:
            if electrode['electrode_id'] == electrode_id:
                return electrode
        return None

    def get_electrode_by_coords(self, coords: Tuple[int, int, int]) -> Dict:
        """Retrieve electrode information by grid coordinates (array_type, row, col)."""
        array_type, row, col = coords
        if array_type == 0:  # Big electrode
            for electrode in self.big_electrodes:
                if electrode['grid_position'] == (row, col):
                    return electrode
        else:  # Small electrode
            for electrode in self.small_electrodes:
                if electrode['grid_position'] == (row, col):
                    return electrode
        return None

    def get_surrounding_electrodes(self, coords: Tuple[int, int, int]) -> List[Dict]:
        """Get electrodes in the 8 directions around the given coordinates (including the center)."""
        array_type, row, col = coords
        surrounding = []

        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                new_row, new_col = row + dr, col + dc
                if self.is_valid_coordinate(array_type, new_row, new_col):
                    electrode = self.get_electrode_by_coords((array_type, new_row, new_col))
                    if electrode:
                        surrounding.append(electrode)

        return surrounding

    def is_valid_coordinate(self, array_type: int, row: int, col: int) -> bool:
        """Check if the coordinate is within valid bounds."""
        if array_type == 0:  # Big electrode
            return 0 <= row < 6 and 0 <= col < 8
        else:  # Small electrode
            return 0 <= row < 9 and 0 <= col < 6

    def mark_electrode_as_obstacle(self, electrode_id: int):
        """Mark an electrode as an obstacle."""
        self.electrode_status[electrode_id] = 'obstacle'
        self.obstacle_electrodes.add(electrode_id)
        print(f"Marked electrode {electrode_id} as obstacle")

    def mark_electrode_as_damaged(self, electrode_id: int):
        """Mark an electrode as damaged."""
        self.electrode_status[electrode_id] = 'damaged'
        self.obstacle_electrodes.add(electrode_id)
        print(f"Marked electrode {electrode_id} as damaged")

    def mark_electrode_as_normal(self, electrode_id: int):
        """Restore an electrode to normal status."""
        self.electrode_status[electrode_id] = 'normal'
        if electrode_id in self.obstacle_electrodes:
            self.obstacle_electrodes.remove(electrode_id)

    def get_obstacle_electrodes(self) -> List[int]:
        """Return list of electrode IDs currently marked as obstacles."""
        return list(self.obstacle_electrodes)

    def mark_droplet_surrounding_as_obstacles(self, droplet_coords: Tuple[int, int, int]):
        """Mark the 8 neighboring electrodes of a droplet as obstacles to prevent merging."""
        surrounding_electrodes = self.get_surrounding_electrodes(droplet_coords)
        for electrode in surrounding_electrodes:
            self.mark_electrode_as_obstacle(electrode['electrode_id'])

    def save_electrode_segmentation_image(self, frame: np.ndarray, output_dir: str):
        """Save a visualization of the electrode segmentation."""
        try:
            seg_frame = frame.copy()

            # Draw big electrodes
            for electrode in self.big_electrodes:
                x_min, y_min, x_max, y_max = electrode['bbox']
                color = (0, 255, 0)  # Green

                status = self.electrode_status.get(electrode['electrode_id'], 'normal')
                if status == 'obstacle':
                    color = (0, 0, 255)  # Red - obstacle
                elif status == 'damaged':
                    color = (128, 0, 128)  # Purple - damaged

                cv2.rectangle(seg_frame,
                              (int(x_min), int(y_min)),
                              (int(x_max), int(y_max)),
                              color, 2)
                cv2.putText(seg_frame, str(electrode['electrode_id']),
                            (int(x_min) + 5, int(y_min) + 20),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

            # Draw small electrodes
            for electrode in self.small_electrodes:
                x_min, y_min, x_max, y_max = electrode['bbox']
                color = (255, 0, 0)  # Blue

                status = self.electrode_status.get(electrode['electrode_id'], 'normal')
                if status == 'obstacle':
                    color = (0, 0, 255)  # Red - obstacle
                elif status == 'damaged':
                    color = (128, 0, 128)  # Purple - damaged

                cv2.rectangle(seg_frame,
                              (int(x_min), int(y_min)),
                              (int(x_max), int(y_max)),
                              color, 2)
                cv2.putText(seg_frame, str(electrode['electrode_id']),
                            (int(x_min) + 5, int(y_min) + 20),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

            # Draw alignment chips
            if self.chip1_coords:
                x_min, y_min, x_max, y_max = self.chip1_coords['bbox']
                cv2.rectangle(seg_frame,
                              (int(x_min), int(y_min)),
                              (int(x_max), int(y_max)),
                              (0, 255, 255), 3)  # Yellow
                cv2.putText(seg_frame, "CHIP1",
                            (int(x_min), int(y_min) - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

            if self.chip2_coords:
                x_min, y_min, x_max, y_max = self.chip2_coords['bbox']
                cv2.rectangle(seg_frame,
                              (int(x_min), int(y_min)),
                              (int(x_max), int(y_max)),
                              (0, 255, 255), 3)  # Yellow
                cv2.putText(seg_frame, "CHIP2",
                            (int(x_min), int(y_min) - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

            # Add title and legend
            cv2.putText(seg_frame, "Electrode Segmentation Result",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.putText(seg_frame, "Green: Big, Blue: Small, Yellow: Chip, Red: Obstacle, Purple: Damaged",
                        (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            # Save image
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(output_dir, f"electrode_segmentation_{timestamp}.jpg")
            cv2.imwrite(output_path, seg_frame)
            # print(f"Electrode segmentation image saved to: {output_path}")  # commented out

            return output_path

        except Exception as e:
            print(f"Failed to save electrode segmentation image: {e}")
            return None

    def detect_chips(self, image_path: str) -> Dict[str, Any]:
        """Detect chip1 and chip2 using the chip model."""
        results = self.chip_model(image_path)
        chips = {}

        for result in results:
            orig_h, orig_w = result.orig_shape

            for box in result.boxes:
                cls_idx = int(box.cls.item())
                cls_name = chip_class_names[cls_idx]

                if cls_name in ['chip1', 'chip2']:
                    x_center_n, y_center_n, w_n, h_n = box.xywhn[0].tolist()
                    x_center = x_center_n * orig_w
                    y_center = y_center_n * orig_h
                    width = w_n * orig_w
                    height = h_n * orig_h

                    x_min = x_center - width / 2
                    y_min = y_center - height / 2
                    x_max = x_center + width / 2
                    y_max = y_center + height / 2

                    chips[cls_name] = {
                        'center': (x_center, y_center),
                        'bbox': (x_min, y_min, x_max, y_max),
                        'size': (width, height)
                    }

        return chips

    def segment_electrodes(self, chips: Dict[str, Any], image_shape: Tuple[int, int]) -> None:
        """Segment all electrodes based on chip1 and chip2 positions."""
        if 'chip1' not in chips or 'chip2' not in chips:
            raise ValueError("chip1 and chip2 not detected")

        chip1 = chips['chip1']
        chip2 = chips['chip2']

        self.chip1_coords = chip1
        self.chip2_coords = chip2

        self._segment_big_electrodes(chip1, image_shape)
        self._segment_small_electrodes(chip2, image_shape)

    def _segment_big_electrodes(self, chip1: Dict, image_shape: Tuple[int, int]) -> None:
        """Segment the big electrode array (6x8) using chip1 as origin."""
        chip1_bbox = chip1['bbox']
        chip1_width, chip1_height = chip1['size']

        electrode_width = chip1_width + 0.75
        electrode_height = chip1_height + 0.6

        start_x = chip1_bbox[0]  # x_min
        start_y = chip1_bbox[1]  # y_min

        self.big_electrodes = []

        for row in range(6):
            for col in range(8):
                x_min = start_x + col * electrode_width
                y_min = start_y + row * electrode_height
                x_max = x_min + electrode_width
                y_max = y_min + electrode_height

                x_min = max(0, x_min)
                y_min = max(0, y_min)
                x_max = min(image_shape[1], x_max)
                y_max = min(image_shape[0], y_max)

                electrode_info = {
                    'bbox': (x_min, y_min, x_max, y_max),
                    'grid_position': (row, col),
                    'electrode_id': big_grid[row][col],
                    'type': 'big',
                    'center': ((x_min + x_max) / 2, (y_min + y_max) / 2),
                    'coords': (0, row, col)
                }
                self.big_electrodes.append(electrode_info)

    def _segment_small_electrodes(self, chip2: Dict, image_shape: Tuple[int, int]) -> None:
        """Segment the small electrode array (9x6) using chip2 as origin."""
        chip2_bbox = chip2['bbox']
        chip2_width, chip2_height = chip2['size']

        electrode_width = chip2_width
        electrode_height = chip2_height - 0.3

        start_x = chip2_bbox[0]  # x_min
        start_y = chip2_bbox[1]  # y_min

        self.small_electrodes = []

        for row in range(9):
            for col in range(6):
                x_min = start_x + col * electrode_width
                y_min = start_y + row * electrode_height
                x_max = x_min + electrode_width
                y_max = y_min + electrode_height

                x_min = max(0, x_min)
                y_min = max(0, y_min)
                x_max = min(image_shape[1], x_max)
                y_max = min(image_shape[0], y_max)

                electrode_info = {
                    'bbox': (x_min, y_min, x_max, y_max),
                    'grid_position': (row, col),
                    'electrode_id': small_grid[row][col],
                    'type': 'small',
                    'center': ((x_min + x_max) / 2, (y_min + y_max) / 2),
                    'coords': (1, row, col)
                }
                self.small_electrodes.append(electrode_info)

    def get_droplet_electrode(self, droplet_bbox):
        """Return the electrode that has the maximum intersection area with the droplet."""
        max_area = 0
        target_electrode = None

        for electrode in self.big_electrodes + self.small_electrodes:
            area = self._intersection_area(droplet_bbox, electrode['bbox'])
            if area > max_area:
                max_area = area
                target_electrode = electrode

        return target_electrode

    def _intersection_area(self, bbox1, bbox2):
        """Compute intersection area of two bounding boxes."""
        x1_min, y1_min, x1_max, y1_max = bbox1
        x2_min, y2_min, x2_max, y2_max = bbox2

        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)

        if inter_x_max < inter_x_min or inter_y_max < inter_y_min:
            return 0.0

        return (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)

    def detect_droplet_positions_in_frame(self, frame: np.ndarray) -> List[Dict]:
        """Detect droplets in a single frame and determine contacted electrodes."""
        results = self.droplet_model(frame)
        droplets = []

        for result in results:
            orig_h, orig_w = result.orig_shape

            for box in result.boxes:
                cls_idx = int(box.cls.item())
                cls_name = droplet_class_names[cls_idx]

                x_center_n, y_center_n, w_n, h_n = box.xywhn[0].tolist()
                x_center = x_center_n * orig_w
                y_center = y_center_n * orig_h
                width = w_n * orig_w
                height = h_n * orig_h

                x_min = x_center - width / 2
                y_min = y_center - height / 2
                x_max = x_center + width / 2
                y_max = y_center + height / 2

                droplet_bbox = (x_min, y_min, x_max, y_max)
                contacted_electrodes = self._find_contacted_electrodes(droplet_bbox)
                main_electrode = self.get_droplet_electrode(droplet_bbox)

                droplet_info = {
                    'type': cls_name,
                    'center': (x_center, y_center),
                    'bbox': droplet_bbox,
                    'size': (width, height),
                    'contacted_electrodes': contacted_electrodes,
                    'main_electrode': main_electrode,
                    'confidence': box.conf.item()
                }

                droplets.append(droplet_info)

        return droplets

    def _calculate_iou(self, bbox1: Tuple, bbox2: Tuple) -> float:
        """Calculate IoU of two bounding boxes."""
        x1_min, y1_min, x1_max, y1_max = bbox1
        x2_min, y2_min, x2_max, y2_max = bbox2

        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)

        inter_area = max(0, inter_x_max - inter_x_min) * max(0, inter_y_max - inter_y_min)

        area1 = (x1_max - x1_min) * (y1_max - y1_min)
        area2 = (x2_max - x2_min) * (y2_max - y2_min)
        union_area = area1 + area2 - inter_area

        return inter_area / union_area if union_area > 0 else 0

    def _find_contacted_electrodes(self, droplet_bbox: Tuple) -> List[Dict]:
        """Find all electrodes that intersect with the droplet bounding box."""
        contacted = []

        for electrode in self.big_electrodes:
            if self._bboxes_intersect(droplet_bbox, electrode['bbox']):
                contacted.append(electrode)

        for electrode in self.small_electrodes:
            if self._bboxes_intersect(droplet_bbox, electrode['bbox']):
                contacted.append(electrode)

        return contacted

    def _bboxes_intersect(self, bbox1: Tuple, bbox2: Tuple) -> bool:
        """Check if two bounding boxes intersect."""
        x1_min, y1_min, x1_max, y1_max = bbox1
        x2_min, y2_min, x2_max, y2_max = bbox2

        if (x1_min < x2_max and x1_max > x2_min and
                y1_min < y2_max and y1_max > y2_min):
            return True
        return False

    def visualize_frame(self, frame: np.ndarray, droplets: List[Dict],
                        mode_display: str = "all") -> np.ndarray:
        """Visualize detection results on a frame."""
        result_frame = frame.copy()

        if mode_display in ["all", "electrodes_only"]:
            # Draw big electrodes
            for electrode in self.big_electrodes:
                x_min, y_min, x_max, y_max = electrode['bbox']
                color = (255, 127, 127)  # default

                status = self.electrode_status.get(electrode['electrode_id'], 'normal')
                if status == 'obstacle':
                    color = (0, 0, 255)  # red
                elif status == 'damaged':
                    color = (128, 0, 128)  # purple

                cv2.rectangle(result_frame,
                              (int(x_min), int(y_min)),
                              (int(x_max), int(y_max)),
                              color, 2)

                if mode_display == "all":
                    cv2.putText(result_frame, str(electrode['electrode_id']),
                                (int(x_min) + 5, int(y_min) + 20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

            # Draw small electrodes
            for electrode in self.small_electrodes:
                x_min, y_min, x_max, y_max = electrode['bbox']
                color = (255, 127, 127)

                status = self.electrode_status.get(electrode['electrode_id'], 'normal')
                if status == 'obstacle':
                    color = (0, 0, 255)
                elif status == 'damaged':
                    color = (128, 0, 128)

                cv2.rectangle(result_frame,
                              (int(x_min), int(y_min)),
                              (int(x_max), int(y_max)),
                              color, 2)

                if mode_display == "all":
                    cv2.putText(result_frame, str(electrode['electrode_id']),
                                (int(x_min) + 5, int(y_min) + 20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

        # Draw droplets
        for droplet in droplets:
            x_min, y_min, x_max, y_max = droplet['bbox']

            colors = {
                'static': (0, 255, 255),  # yellow
                'merging': (0, 165, 255), # orange
                'splitting': (255, 0, 255), # purple
                'stretching': (0, 0, 255)  # red
            }
            color = colors.get(droplet['type'], (255, 255, 255))

            cv2.rectangle(result_frame,
                          (int(x_min), int(y_min)),
                          (int(x_max), int(y_max)),
                          color, 3)

            main_electrode_id = droplet['main_electrode']['electrode_id'] if droplet['main_electrode'] else "Unknown"
            info_text = f"{droplet['type']} on {main_electrode_id}"
            cv2.putText(result_frame, info_text,
                        (int(x_min), int(y_min) - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        return result_frame

    def process_single_frame(self, frame: np.ndarray) -> List[Dict]:
        """Process a single frame and return detected droplet information."""
        if not self.electrodes_initialized:
            if not self.initialize_electrodes_from_frame(frame):
                print("Electrode initialization failed")
                return []

        return self.detect_droplet_positions_in_frame(frame)
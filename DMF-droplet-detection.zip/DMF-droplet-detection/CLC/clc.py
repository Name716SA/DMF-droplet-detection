import cv2
import time
import os
import sys
import numpy as np
import psutil
from routing import PathPlanner, send_commands, big_grid, small_grid
from Yolo_DropletTracker import VideoElectrodeDetector, DropletTracker
import config

# ===================== Configuration (Edit here) =====================
# Select operating mode: 1 = single image, 2 = real-time control
MODE = 1

# File paths (used when MODE = 1)
IMAGE_PATH = r"I:/PythonProjectYolo/DMF-droplet-detection/test_iv/test3.jpg"

# Real-time control settings (used when MODE = 2)
TARGET_COORDS = "000"            # Destination coordinates (e.g., "001" for big electrode (0,1))
CAMERA_ID = config.CAMERA_ID     # Camera device ID (default from config)
COMMAND_BASE_DIR = config.COMMAND_BASE_DIR  # Directory for hardware command files
# =====================================================================

# Force CPU inference (modify if GPU is desired)
os.environ["CUDA_VISIBLE_DEVICES"] = ""

# ---------- Optional libraries for GPU monitoring and model analysis ----------
try:
    import pynvml
    pynvml.nvmlInit()
    GPU_AVAILABLE = True
except:
    GPU_AVAILABLE = False

try:
    from thop import profile
    THOP_AVAILABLE = True
except:
    THOP_AVAILABLE = False

try:
    from torchinfo import summary
    TORCHINFO_AVAILABLE = True
except:
    TORCHINFO_AVAILABLE = False

import torch


class PerformanceMonitor:
    """Lightweight performance monitor: latency, FPS, memory, etc."""

    def __init__(self):
        self.start_time = time.perf_counter()
        self.frame_count = 0
        self.total_inference_time = 0.0
        self.total_path_plan_time = 0.0
        self.path_replans = 0
        self.decision_latencies = []
        self.closed_loop_start = None
        self.closed_loop_end = None
        self.cpu_memory_samples = []
        self.gpu_memory_samples = []

        # Model statistics (computed once)
        self.model_params = None
        self.model_flops = None
        self._compute_model_stats()

    def _compute_model_stats(self):
        if not THOP_AVAILABLE and not TORCHINFO_AVAILABLE:
            return
        try:
            detector = VideoElectrodeDetector()
            model = detector.droplet_model.model
            model.to('cpu')
            device = torch.device('cpu')
            dummy_input = torch.randn(1, 3, 640, 640).to(device)

            if THOP_AVAILABLE:
                flops, params = profile(model, inputs=(dummy_input,), verbose=False)
                self.model_params = params / 1e6
                self.model_flops = flops / 1e9
            elif TORCHINFO_AVAILABLE:
                info = summary(model, input_size=(1, 3, 640, 640), verbose=0)
                self.model_params = info.total_params / 1e6
                self.model_flops = (
                    info.total_mult_adds / 1e9 if info.total_mult_adds else None
                )
        except:
            pass

    def record_inference_time(self, dt: float):
        self.total_inference_time += dt
        self.frame_count += 1

    def record_path_plan_time(self, dt: float):
        self.total_path_plan_time += dt

    def record_replan(self):
        self.path_replans += 1

    def record_decision_latency(self, capture_time: float, command_time: float):
        self.decision_latencies.append(command_time - capture_time)

    def sample_memory(self):
        try:
            process = psutil.Process()
            mem_mb = process.memory_info().rss / 1024**2
            self.cpu_memory_samples.append(mem_mb)
        except:
            pass
        if GPU_AVAILABLE:
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                self.gpu_memory_samples.append(info.used / 1024**2)
            except:
                pass

    def mark_closed_loop_start(self):
        self.closed_loop_start = time.perf_counter()

    def mark_closed_loop_end(self):
        self.closed_loop_end = time.perf_counter()

    def get_summary(self):
        """Return a dictionary of performance metrics (not printed by default)."""
        summary = {}
        if self.model_params is not None:
            summary['model_params'] = self.model_params
        if self.model_flops is not None:
            summary['model_flops'] = self.model_flops

        if self.cpu_memory_samples:
            summary['cpu_mem_avg'] = np.mean(self.cpu_memory_samples)
            summary['cpu_mem_peak'] = np.max(self.cpu_memory_samples)
        if self.gpu_memory_samples:
            summary['gpu_mem_avg'] = np.mean(self.gpu_memory_samples)
            summary['gpu_mem_peak'] = np.max(self.gpu_memory_samples)

        if self.frame_count > 0:
            summary['infer_avg_ms'] = self.total_inference_time / self.frame_count * 1000
            summary['total_frames'] = self.frame_count
            total_time = time.perf_counter() - self.start_time
            if total_time > 0:
                summary['eff_fps'] = self.frame_count / total_time

        if self.decision_latencies:
            summary['decision_lat_avg_ms'] = np.mean(self.decision_latencies) * 1000
            summary['decision_lat_max_ms'] = np.max(self.decision_latencies) * 1000

        if self.path_replans > 0 or self.total_path_plan_time > 0:
            summary['path_plan_total_ms'] = self.total_path_plan_time * 1000
            summary['replans'] = self.path_replans

        if self.closed_loop_start and self.closed_loop_end:
            summary['closed_loop_time_s'] = self.closed_loop_end - self.closed_loop_start

        return summary


# ================== Core Control Class ==================

class DropletClosedLoopControl:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.detector = VideoElectrodeDetector()
        self.planner = PathPlanner()
        self.current_path = []
        self.current_step = 0
        self.obstacles = set()
        self.target_coords = None
        self.is_running = False
        self.cap = None
        self.last_verified_coords = None
        self.command_execution_time = 2.5
        self.movement_timeout = 7

        self.droplet_tracker = DropletTracker(detector=self.detector)
        self.main_droplet_id = None
        self.other_droplet_ids = set()

        self.perf = PerformanceMonitor()

    # ---------- Coordinate parsing ----------
    def parse_destination_input(self, input_str):
        try:
            if len(input_str) != 3:
                raise ValueError("Format: 3 digits, e.g. 001")
            array_type = int(input_str[0])
            row = int(input_str[1])
            col = int(input_str[2])
            if array_type == 0:
                if 0 <= row < 6 and 0 <= col < 8:
                    return (array_type, row, col)
                else:
                    raise ValueError("Big electrode coordinates out of range")
            elif array_type == 1:
                if 0 <= row < 9 and 0 <= col < 6:
                    return (array_type, row, col)
                else:
                    raise ValueError("Small electrode coordinates out of range")
            else:
                raise ValueError("First digit must be 0 or 1")
        except Exception as e:
            print(f"Input error: {e}")
            return None

    # ---------- Droplet tracking initialization ----------
    def initialize_droplet_tracking(self, frame):
        print("Initializing droplet tracking...")
        for _ in range(10):
            ret, frame = self.cap.read()
            if not ret:
                continue
            droplets = self.detector.process_single_frame(frame)
            if droplets:
                droplet_data = []
                for d in droplets:
                    coords = self.get_droplet_coordinates_from_droplet(d)
                    if coords:
                        center = self.coords_to_pixel_center(coords)
                        droplet_data.append({
                            'coords': coords,
                            'center': center,
                            'electrode_id': d.get('main_electrode', {}).get('electrode_id', 'Unknown'),
                            'type': d['type']
                        })
                if droplet_data:
                    self.droplet_tracker.update(droplet_data)
            time.sleep(0.1)

        tracked = self.droplet_tracker.get_tracked_droplets()
        if not tracked:
            print("No stable droplets detected.")
            return False
        print("Detected droplets:")
        for k, v in tracked.items():
            print(f"  ID {k}: pos {v['coords']}, type {v.get('type','?')}")
        return True

    def select_main_droplet_by_id(self, frame):
        """Allow user to select the main droplet if multiple are found."""
        tracked = self.droplet_tracker.get_tracked_droplets()
        if not tracked:
            return None
        if len(tracked) == 1:
            drop_id = list(tracked.keys())[0]
            print(f"Only one droplet found. Automatically selected ID: {drop_id}")
            return drop_id

        # Multiple droplets: ask user to pick
        print("Multiple droplets detected. Please select the one to move:")
        for k, v in tracked.items():
            print(f"  ID {k}: pos {v['coords']}, type {v.get('type','?')}")
        try:
            choice = int(input("Enter droplet ID: "))
            return choice if choice in tracked else list(tracked.keys())[0]
        except:
            return list(tracked.keys())[0]

    def get_droplet_coordinates_from_droplet(self, droplet):
        if not droplet:
            return None
        main_electrode = droplet.get('main_electrode')
        if main_electrode:
            if 'coords' in main_electrode:
                return main_electrode['coords']
            elif 'grid_position' in main_electrode:
                array_type = 0 if main_electrode['type'] == 'big' else 1
                row, col = main_electrode['grid_position']
                return (array_type, row, col)
        return None

    def coords_to_pixel_center(self, coords):
        array_type, row, col = coords
        if array_type == 0:
            ew, eh, sx, sy = 100, 80, 100, 100
        else:
            ew, eh, sx, sy = 60, 50, 600, 100
        center_x = sx + col * ew + ew / 2
        center_y = sy + row * eh + eh / 2
        return (center_x, center_y)

    # ---------- Get main droplet current coordinates (with performance recording) ----------
    def get_current_droplet_coordinates(self, frame):
        t0 = time.perf_counter()
        try:
            droplets = self.detector.process_single_frame(frame)
            t1 = time.perf_counter()
            self.perf.record_inference_time(t1 - t0)

            if droplets:
                droplet_data = []
                for d in droplets:
                    coords = self.get_droplet_coordinates_from_droplet(d)
                    if coords:
                        center = self.coords_to_pixel_center(coords)
                        droplet_data.append({
                            'coords': coords,
                            'center': center,
                            'electrode_id': d.get('main_electrode', {}).get('electrode_id', 'Unknown'),
                            'type': d['type']
                        })
                self.droplet_tracker.update(droplet_data)

            tracked = self.droplet_tracker.get_tracked_droplets()
            if self.main_droplet_id in tracked:
                return tracked[self.main_droplet_id]['coords']
            else:
                print(f"Main droplet ID {self.main_droplet_id} lost!")
                return None
        except Exception as e:
            print(f"Error getting coordinates: {e}")
            return None

    def get_main_droplet_info(self, frame):
        t0 = time.perf_counter()
        try:
            droplets = self.detector.process_single_frame(frame)
            t1 = time.perf_counter()
            self.perf.record_inference_time(t1 - t0)

            if droplets:
                droplet_data = []
                for d in droplets:
                    coords = self.get_droplet_coordinates_from_droplet(d)
                    if coords:
                        center = self.coords_to_pixel_center(coords)
                        droplet_data.append({
                            'coords': coords,
                            'center': center,
                            'electrode_id': d.get('main_electrode', {}).get('electrode_id', 'Unknown'),
                            'type': d['type']
                        })
                self.droplet_tracker.update(droplet_data)

            tracked = self.droplet_tracker.get_tracked_droplets()
            if self.main_droplet_id in tracked:
                return tracked[self.main_droplet_id]
            return None
        except Exception as e:
            print(f"Error getting main droplet info: {e}")
            return None

    def mark_other_droplets_as_obstacles(self, frame):
        try:
            tracked = self.droplet_tracker.get_tracked_droplets()
            obstacle_set = set()
            for drop_id, drop in tracked.items():
                if drop_id == self.main_droplet_id:
                    continue
                array_type, row, col = drop['coords']
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        nr, nc = row + dr, col + dc
                        if self.is_valid_coordinate(array_type, nr, nc):
                            obstacle_set.add((array_type, nr, nc))
            for coord in obstacle_set:
                self.planner.add_obstacle(coord)
                self.obstacles.add(coord)
            print(f"Marked {len(obstacle_set)} positions as obstacles")
        except Exception as e:
            print(f"Error marking obstacles: {e}")

    def is_valid_coordinate(self, array_type, row, col):
        return (0 <= row < 6 and 0 <= col < 8) if array_type == 0 else (0 <= row < 9 and 0 <= col < 6)

    def verify_current_position(self, frame, expected_coords):
        current = self.get_current_droplet_coordinates(frame)
        if current == expected_coords:
            self.last_verified_coords = current
            return True
        else:
            print(f"Position verification failed: expected {expected_coords}, actual {current}")
            return False

    def check_destination_reached(self, frame):
        current = self.get_current_droplet_coordinates(frame)
        return current == self.target_coords

    def wait_for_droplet_movement(self, target_coords, timeout=None):
        if timeout is None:
            timeout = self.movement_timeout
        start = time.time()
        time.sleep(self.command_execution_time)
        adjusted_timeout = timeout - self.command_execution_time
        if adjusted_timeout <= 0:
            adjusted_timeout = 1
        consecutive = 0
        while time.time() - start < adjusted_timeout:
            ret, frame = self.cap.read()
            if not ret:
                continue
            current = self.get_current_droplet_coordinates(frame)
            if current == target_coords:
                consecutive += 1
                if consecutive >= 3:
                    print(f"✓ Reached target {target_coords}")
                    self.last_verified_coords = current
                    return True
            else:
                consecutive = 0
            time.sleep(0.1)
        print(f"✗ Timeout: did not reach {target_coords}")
        return False

    def execute_movement_step(self, current_coords, next_coords):
        cur_elec = self.planner.get_electrode_number(current_coords)
        nxt_elec = self.planner.get_electrode_number(next_coords)
        print(f"Move: {cur_elec} @ {current_coords} -> {nxt_elec} @ {next_coords}")

        ret, frame = self.cap.read()
        capture_time = time.perf_counter()
        self.perf.sample_memory()
        if not ret or not self.verify_current_position(frame, current_coords):
            return False

        max_retries = 1
        for attempt in range(max_retries + 1):
            if attempt > 0:
                print(f"--- Retry activating electrode {nxt_elec} (attempt {attempt}) ---")

            commands = self.planner.generate_single_step_command(cur_elec, nxt_elec)
            command_time = time.perf_counter()
            self.perf.record_decision_latency(capture_time, command_time)

            if not send_commands(commands, self.base_dir):
                print("Command sending failed")
                return False

            print("Command sent, waiting for execution...")
            exec_start = time.time()
            while time.time() - exec_start < self.command_execution_time:
                ret, frame = self.cap.read()
                time.sleep(0.1)

            print("Monitoring movement...")
            if self.wait_for_droplet_movement(next_coords, self.movement_timeout):
                return True

            # Movement failed, diagnose
            ret, frame = self.cap.read()
            if not ret:
                continue
            info = self.get_main_droplet_info(frame)
            if info is None:
                continue
            current_after = info['coords']
            cur_type = info['type']
            if current_after == current_coords and cur_type == 'static':
                print(f"Droplet still at {current_coords} and static, target electrode not responding")
                if attempt < max_retries:
                    print("Retrying...")
                    continue
                else:
                    static_confirm = True
                    for _ in range(3):
                        time.sleep(0.2)
                        ret, frm = self.cap.read()
                        if not ret:
                            continue
                        c_info = self.get_main_droplet_info(frm)
                        if c_info is None or c_info['coords'] != current_coords or c_info['type'] != 'static':
                            static_confirm = False
                            break
                    if static_confirm:
                        print(f"Confirmed: droplet not moved, marking electrode {nxt_elec} as obstacle")
                        self.planner.add_obstacle(next_coords)
                        self.obstacles.add(next_coords)
                        self.detector.mark_electrode_as_damaged(nxt_elec)
                    return False
            else:
                print(f"Droplet moved to {current_after} (type {cur_type}), will replan")
                return False
        return False

    # ---------- Camera ----------
    def initialize_camera(self, camera_id=1):
        self.cap = cv2.VideoCapture(camera_id)
        if not self.cap.isOpened():
            print(f"Cannot open camera {camera_id}")
            return False
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        for _ in range(10):
            if self.cap.read()[0]:
                break
            time.sleep(0.1)
        print("Camera initialized successfully")
        return True

    # ---------- Main real-time control loop ----------
    def run_closed_loop_control(self, destination_input):
        self.target_coords = self.parse_destination_input(destination_input)
        if self.target_coords is None:
            return

        self.perf.mark_closed_loop_start()

        if not self.initialize_camera(CAMERA_ID):
            return

        ret, frame = self.cap.read()
        if not ret:
            return

        if not self.detector.initialize_electrodes_from_frame(frame):
            print("Electrode initialization failed")
            return

        if not self.initialize_droplet_tracking(frame):
            return

        self.main_droplet_id = self.select_main_droplet_by_id(frame)
        if self.main_droplet_id is None:
            print("No main droplet selected")
            return
        print(f"Main droplet ID: {self.main_droplet_id}")
        self.mark_other_droplets_as_obstacles(frame)

        try:
            self.is_running = True
            consecutive_failures = 0
            while self.is_running and consecutive_failures < 60:
                ret, frame = self.cap.read()
                if not ret:
                    consecutive_failures += 1
                    continue
                current_coords = self.get_current_droplet_coordinates(frame)
                if current_coords is None:
                    consecutive_failures += 1
                    continue
                else:
                    consecutive_failures = 0

                cur_elec = self.planner.get_electrode_number(current_coords)
                print(f"Current: electrode {cur_elec} @ {current_coords}")

                if self.check_destination_reached(frame):
                    print("Destination reached!")
                    break

                if not self.current_path or self.current_step >= len(self.current_path):
                    print("Path planning...")
                    t0 = time.perf_counter()
                    self.current_path = self.planner.find_path_by_coordinates(
                        current_coords, self.target_coords
                    )
                    t1 = time.perf_counter()
                    self.perf.record_path_plan_time(t1 - t0)
                    self.perf.record_replan()
                    self.current_step = 0
                    if not self.current_path:
                        print("No feasible path!")
                        break
                    print(f"Path: {[self.planner.get_electrode_number(c) for c in self.current_path]}")
                    self.last_verified_coords = current_coords

                if self.current_step < len(self.current_path) - 1:
                    next_target = self.current_path[self.current_step + 1]
                    if self.last_verified_coords != current_coords:
                        print("Position changed, replanning")
                        self.current_path = []
                        continue
                    success = self.execute_movement_step(current_coords, next_target)
                    if success:
                        self.current_step += 1
                    else:
                        print("Move failed, replanning")
                        self.current_path = []
                        self.current_step = 0
                else:
                    print("Path completed")
                    break
        finally:
            if self.cap:
                self.cap.release()
            self.is_running = False

        self.perf.mark_closed_loop_end()

    # ---------- Single image inference ----------
    @staticmethod
    def single_image_inference(image_path):
        """Run inference on a single image and display the result."""
        if not os.path.exists(image_path):
            print(f"Image not found: {image_path}")
            return
        detector = VideoElectrodeDetector()
        img = cv2.imread(image_path)
        if img is None:
            print("Failed to read image.")
            return
        if not detector.initialize_electrodes_from_frame(img):
            print("Electrode initialization failed on this image.")
            return
        droplets = detector.process_single_frame(img)
        vis = detector.visualize_frame(img, droplets)
        cv2.imshow("Single Image Inference", vis)
        print("Press any key to close the window.")
        cv2.waitKey(0)
        cv2.destroyAllWindows()


def main():
    if MODE == 1:
        print(f"Running single image inference on: {IMAGE_PATH}")
        DropletClosedLoopControl.single_image_inference(IMAGE_PATH)
    elif MODE == 2:
        print(f"Starting real-time control to target: {TARGET_COORDS}")
        if not os.path.exists(COMMAND_BASE_DIR):
            os.makedirs(COMMAND_BASE_DIR, exist_ok=True)
        ctrl = DropletClosedLoopControl(COMMAND_BASE_DIR)
        ctrl.run_closed_loop_control(TARGET_COORDS)
    else:
        print("Invalid MODE value. Please set MODE to 1 (single image) or 2 (real-time control).")

    print("Program finished.")

if __name__ == "__main__":
    main()
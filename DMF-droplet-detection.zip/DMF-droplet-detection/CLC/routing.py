import heapq
import os
import time
import sys

class PriorityQueue:
    def __init__(self):
        self.elements = []

    def empty(self):
        return len(self.elements) == 0

    def put(self, item, priority):
        heapq.heappush(self.elements, (priority, item))

    def get(self):
        return heapq.heappop(self.elements)[1]


# 定义大电极阵列 (6行8列)
big_grid = [
    [46, 47, 48, 49, 50, 13, 24, 30],
    [38, 39, 40, 41, 42, 43, 44, 45],
    [30, 31, 32, 33, 34, 35, 36, 37],
    [22, 23, 24, 25, 26, 27, 28, 29],
    [14, 15, 16, 17, 18, 19, 20, 21],
    [6, 7, 8, 9, 10, 11, 12, 13]
]

# 定义小电极阵列 (9行6列)
small_grid = [
    [36, 37, 30, 25, 24, 18],
    [13, 12, 6, 50, 49, 48],
    [47, 46, 45, 44, 43, 42],
    [41, 40, 39, 38, 37, 36],
    [35, 34, 33, 32, 31, 30],
    [28, 27, 29, 26, 25, 24],
    [22, 23, 21, 20, 19, 18],
    [17, 16, 15, 14, 13, 12],
    [11, 10, 9, 8, 7, 6]
]

# 定义边界连接关系 (大电极 -> 小电极)
big_to_small = {
    (0, 0, 7): [(1, 0, 0)],  # 大电极(0,7) -> 小电极 (0,0)
    (0, 1, 7): [(1, 2, 0)],  # 大电极(1,7) -> 小电极 (2,0)
    (0, 2, 7): [(1, 3, 0)],  # 大电极(2,7) -> 小电极 (3,0)
    (0, 3, 7): [(1, 5, 0)],  # 大电极(3,7) -> 小电极 (5,0)
    (0, 4, 7): [(1, 6, 0)],  # 大电极(4,7) -> 小电极 (6,0)
    (0, 5, 7): [(1, 8, 0)]   # 大电极(5,7) -> 小电极 (8,0)
}

# 定义大电极到小电极移动时的辅助电极映射
big_to_small_assistant_electrodes = {
    # 格式: (大电极坐标): (目标小电极编号, 辅助电极编号)
    (0, 0, 7): (36, 37),  # big_grid[0][7] (30) -> small_grid[0][0] (36) 辅助电极13
    (0, 1, 7): (47, 46),  # big_grid[1][7] (45) -> small_grid[2][0] (47) 辅助电极13
    (0, 2, 7): (41, 40),  # big_grid[2][7] (37) -> small_grid[3][0] (41) 辅助电极35
    (0, 3, 7): (28, 27),  # big_grid[3][7] (29) -> small_grid[5][0] (28) 辅助电极35
    (0, 4, 7): (22, 23),  # big_grid[4][7] (21) -> small_grid[6][0] (22) 辅助电极17
    (0, 5, 7): (11, 10)   # big_grid[5][7] (13) -> small_grid[8][0] (11) 辅助电极17
}

# 创建反向映射 (小电极 -> 大电极)
small_to_big = {}
for big_pos, small_positions in big_to_small.items():
    for small_pos in small_positions:
        if small_pos not in small_to_big:
            small_to_big[small_pos] = []
        small_to_big[small_pos].append(big_pos)

class PathPlanner:
    def __init__(self, obstacles=None):
        # 修改：障碍物现在存储坐标而不是电极编号
        self.obstacles = set(obstacles) if obstacles else set()

    def add_obstacle(self, coords):
        """添加障碍物坐标"""
        self.obstacles.add(coords)
        print(f"标记坐标 {coords} 为障碍物")

    def remove_obstacle(self, coords):
        """移除障碍物坐标"""
        if coords in self.obstacles:
            self.obstacles.remove(coords)
            print(f"移除坐标 {coords} 的障碍物标记")

    def clear_obstacles(self):
        """清除所有障碍物"""
        self.obstacles.clear()
        print("清除所有障碍物标记")

    def get_electrode_number(self, pos):
        """获取指定位置的电极编号"""
        array_id, row, col = pos
        if array_id == 0:  # 大电极
            if 0 <= row < len(big_grid) and 0 <= col < len(big_grid[0]):
                return big_grid[row][col]
        elif array_id == 1:  # 小电极
            if 0 <= row < len(small_grid) and 0 <= col < len(small_grid[0]):
                return small_grid[row][col]
        return None  # 位置无效

    def get_electrode_position(self, electrode_id):
        """根据电极ID获取位置信息"""
        # 在大电极中查找
        for row in range(len(big_grid)):
            for col in range(len(big_grid[0])):
                if big_grid[row][col] == electrode_id:
                    return (0, row, col)

        # 在小电极中查找
        for row in range(len(small_grid)):
            for col in range(len(small_grid[0])):
                if small_grid[row][col] == electrode_id:
                    return (1, row, col)

        return None  # 未找到

    def is_big_to_small_movement(self, current_coords, next_coords):
        """判断是否是从大电极到小电极的移动"""
        return current_coords[0] == 0 and next_coords[0] == 1

    def get_assistant_electrode_for_big_to_small(self, current_coords, next_electrode_id):
        """获取大电极到小电极移动的辅助电极"""
        # 检查是否有预定义的辅助电极映射
        if current_coords in big_to_small_assistant_electrodes:
            target_electrode, assistant_electrode = big_to_small_assistant_electrodes[current_coords]
            # 验证目标电极是否匹配
            if next_electrode_id == target_electrode:
                return assistant_electrode

        # 如果没有预定义映射，使用默认逻辑：选择目标小电极旁边的电极作为辅助
        # 这里可以根据需要添加默认逻辑
        return None

    def heuristic(self, a, b):
        """改进的启发式函数，处理跨阵列距离"""
        # 如果在同一阵列，使用曼哈顿距离
        if a[0] == b[0]:
            return abs(a[1] - b[1]) + abs(a[2] - b[2])

        # 如果在不同阵列，计算最小边界距离
        min_cost = float('inf')
        if a[0] == 0:  # a是大电极，b是小电极
            # 检查a是否在边界上
            if a in big_to_small:
                for small_pos in big_to_small[a]:
                    # 计算从边界到目标的距离
                    cost = 1 + abs(small_pos[1] - b[1]) + abs(small_pos[2] - b[2])
                    if cost < min_cost:
                        min_cost = cost
        else:  # a是小电极，b是大电极
            # 检查a是否在边界上
            if a in small_to_big:
                for big_pos in small_to_big[a]:
                    # 计算从边界到目标的距离
                    cost = 1 + abs(big_pos[1] - b[1]) + abs(big_pos[2] - b[2])
                    if cost < min_cost:
                        min_cost = cost

        # 如果不在边界上，使用保守估计
        if min_cost == float('inf'):
            # 保守估计：到边界的最小距离 + 1 + 到目标的距离
            if a[0] == 0:  # 大电极
                min_cost = abs(a[2] - 7) + 1 + abs(b[2])
            else:  # 小电极
                min_cost = abs(a[2]) + 1 + abs(b[2] - 7)

        return min_cost


    def find_path_by_coordinates(self, start_coords, goal_coords):
        """基于坐标查找路径，返回坐标路径"""
        start_electrode = self.get_electrode_number(start_coords)
        goal_electrode = self.get_electrode_number(goal_coords)

        if start_electrode is None:
            print(f"错误: 未找到起点坐标 {start_coords} 对应的电极")
            return None

        if goal_electrode is None:
            print(f"错误: 未找到终点坐标 {goal_coords} 对应的电极")
            return None

        print(f"基于坐标的路径规划: 从 {start_coords} (电极{start_electrode}) 到 {goal_coords} (电极{goal_electrode})")

        # 使用A*算法进行路径规划
        came_from, cost_so_far = self.a_star_search(start_coords, goal_coords)
        path = self.reconstruct_path(came_from, start_coords, goal_coords)

        if path is None:
            print("路径规划失败")
            return None

        print(f"规划坐标路径: {path}")

        # 返回坐标路径，而不是电极编号路径
        return path

    def get_neighbors(self, pos):
        """获取有效相邻位置（包括跨阵列移动），避开障碍物"""
        array_id, row, col = pos
        neighbors = []

        # 1. 阵列内部的移动
        if array_id == 0:  # 大电极阵列
            directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # 右, 下, 左, 上
            for dr, dc in directions:
                new_row, new_col = row + dr, col + dc
                if 0 <= new_row < len(big_grid) and 0 <= new_col < len(big_grid[0]):
                    neighbor_pos = (array_id, new_row, new_col)
                    # 修改：检查坐标是否为障碍物，而不是电极编号
                    if neighbor_pos not in self.obstacles:
                        neighbors.append(neighbor_pos)
        else:  # 小电极阵列
            directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # 右, 下, 左, 上
            for dr, dc in directions:
                new_row, new_col = row + dr, col + dc
                if 0 <= new_row < len(small_grid) and 0 <= new_col < len(small_grid[0]):
                    neighbor_pos = (array_id, new_row, new_col)
                    # 修改：检查坐标是否为障碍物，而不是电极编号
                    if neighbor_pos not in self.obstacles:
                        neighbors.append(neighbor_pos)

        # 2. 跨阵列的边界移动
        if array_id == 0:  # 从大电极到小电极
            big_pos = (array_id, row, col)
            if big_pos in big_to_small:
                for small_pos in big_to_small[big_pos]:
                    # 修改：检查坐标是否为障碍物
                    if small_pos not in self.obstacles:
                        neighbors.append(small_pos)
        else:  # 从小电极到大电极
            small_pos = (array_id, row, col)
            if small_pos in small_to_big:
                for big_pos in small_to_big[small_pos]:
                    # 修改：检查坐标是否为障碍物
                    if big_pos not in self.obstacles:
                        neighbors.append(big_pos)

        return neighbors

    def a_star_search(self, start_pos, goal_pos):
        """A*路径规划算法，避开障碍物"""
        frontier = PriorityQueue()
        frontier.put(start_pos, 0)
        came_from = {start_pos: None}
        cost_so_far = {start_pos: 0}

        while not frontier.empty():
            current = frontier.get()

            if current == goal_pos:
                break

            for next_pos in self.get_neighbors(current):
                new_cost = cost_so_far[current] + 1  # 每次移动代价为1

                if next_pos not in cost_so_far or new_cost < cost_so_far[next_pos]:
                    cost_so_far[next_pos] = new_cost
                    priority = new_cost + self.heuristic(next_pos, goal_pos)
                    frontier.put(next_pos, priority)
                    came_from[next_pos] = current

        return came_from, cost_so_far

    def reconstruct_path(self, came_from, start_pos, goal_pos):
        """重建路径并转换为位置序列"""
        current = goal_pos
        path = []
        while current != start_pos:
            path.append(current)
            if current not in came_from:
                print(f"错误: 无法从 {current} 回溯到起点")
                return None
            current = came_from[current]
        path.append(start_pos)
        path.reverse()
        return path

    def path_to_electrodes(self, path):
        """将位置路径转换为电极编号路径"""
        return [self.get_electrode_number(pos) for pos in path]

    def find_path(self, start_electrode_id, goal_electrode_id):
        """查找从起点电极到终点电极的路径"""
        start_pos = self.get_electrode_position(start_electrode_id)
        goal_pos = self.get_electrode_position(goal_electrode_id)

        if start_pos is None:
            print(f"错误: 未找到起点电极 {start_electrode_id}")
            return None

        if goal_pos is None:
            print(f"错误: 未找到终点电极 {goal_electrode_id}")
            return None

        print(f"路径规划: 从电极 {start_electrode_id} 到电极 {goal_electrode_id}")
        came_from, cost_so_far = self.a_star_search(start_pos, goal_pos)
        path = self.reconstruct_path(came_from, start_pos, goal_pos)

        if path is None:
            print("路径规划失败")
            return None

        electrode_path = self.path_to_electrodes(path)
        print(f"规划路径: {electrode_path}")
        return electrode_path

    def generate_single_step_command(self, current_electrode, next_electrode):
        """生成单步移动命令"""
        commands = []
        commands.append(f"chg {current_electrode} {next_electrode} hv 800")
        commands.append("delay 10")
        commands.append(f"chg {current_electrode} {next_electrode} hv 800")
        commands.append(f"chg {next_electrode} hv 800")
        commands.append("delay 10")
        commands.append(f"chg {next_electrode} hv 800")
        return commands

    def generate_single_step_command_big_to_small(self, current_electrode, next_electrode, assistant_electrode):
        """生成大电极到小电极的单步移动命令"""
        commands = []
        # 只激活目标小电极和辅助电极，不激活当前大电极
        commands.append(f"chg {current_electrode} {next_electrode} {assistant_electrode} hv 800")
        commands.append("delay 10")
        commands.append(f"chg {current_electrode} {next_electrode} {assistant_electrode} hv 800")
        commands.append(f"chg {next_electrode} {assistant_electrode} hv 800")
        commands.append("delay 10")
        commands.append(f"chg {next_electrode} {assistant_electrode} hv 800")
        commands.append(f"chg {next_electrode} hv 800")
        commands.append("delay 10")
        commands.append(f"chg {next_electrode} hv 800")
        return commands


def create_lock_file(lock_path):
    """创建lock.txt文件"""
    try:
        with open(lock_path, 'w') as f:
            pass  # 创建空文件
        print(f"已创建lock文件: {lock_path}")
        return True
    except Exception as e:
        print(f"创建lock文件失败: {e}")
        return False


def delete_lock_file(lock_path):
    """删除lock.txt文件"""
    try:
        if os.path.exists(lock_path):
            os.remove(lock_path)
            print(f"已删除lock文件: {lock_path}")
            return True
        else:
            print(f"lock文件不存在: {lock_path}")
            return False
    except Exception as e:
        print(f"删除lock文件失败: {e}")
        return False

def send_commands(commands, base_dir):
    """发送命令序列到硬件"""
    lock_file = os.path.join(base_dir, "lock.txt")
    cmd_file = os.path.join(base_dir, "cmd.txt")

    # 创建lock文件
    if not create_lock_file(lock_file):
        return False

    # 写入命令文件（过滤空行和注释）
    try:
        with open(cmd_file, 'w') as f:
            for command in commands:
                # 跳过空行和以#开头的注释行
                if command.strip() and not command.strip().startswith('#'):
                    f.write(command.strip() + '\n')
        print(f"成功写入 {len([c for c in commands if c.strip() and not c.strip().startswith('#')])} 条命令到 {cmd_file}")
    except Exception as e:
        print(f"写入命令文件失败: {e}")
        delete_lock_file(lock_file)
        return False

    time.sleep(0.3)  # 短暂延迟

    # 删除lock文件
    if not delete_lock_file(lock_file):
        return False

    return True